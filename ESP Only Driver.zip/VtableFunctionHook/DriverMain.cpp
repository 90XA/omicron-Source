#include <ntifs.h>
#include <windef.h>
#include <cstdint>
#include <intrin.h>
#include <ntimage.h>
#include "imports.h"
#include "xor.h"

PVOID change_window_tree_protection_address = 0;
NTSTATUS init_function()
{
	change_window_tree_protection_address = reinterpret_cast<PVOID>(find_pattern_page_km(_("win32kfull.sys"), _(".text"), _("\xE8\x00\x00\x00\x00\x8B\xF0\x85\xC0\x75\x18"), _("x????xxxxxx")));

	if (change_window_tree_protection_address == 0)
		return STATUS_UNSUCCESSFUL;

	change_window_tree_protection_address = reinterpret_cast<PVOID>(to_rva(reinterpret_cast<uintptr_t>(change_window_tree_protection_address), 1));

	//dbgprint("change_window_tree_protection_address : 0x%llx\n", change_window_tree_protection_address);

	return (change_window_tree_protection_address != 0) ? STATUS_SUCCESS : STATUS_UNSUCCESSFUL;
}
int64_t change_window_tree_protection(MEMORY_STRUCT* req)
{
	static const auto validate_hwnd = reinterpret_cast<tag_wnd * (*)(uint64_t)>(get_system_base_export(_("win32kbase.sys"), _("ValidateHwnd")));
	if (!validate_hwnd)
		return 0;

	const auto window_instance = validate_hwnd(req->window_handle);
	if (!window_instance)
		return 0;

	static auto change_window_tree_protection = reinterpret_cast<int64_t(NTAPI*)(struct tag_wnd*, uint32_t)>(change_window_tree_protection_address);
	if (!change_window_tree_protection)
		return 0;

	//dbgprint("change_window_tree_protection : 0x%llx\n", change_window_tree_protection);

	return change_window_tree_protection(window_instance, req->value);
}
NTSTATUS(__fastcall* OriginalFunction)(ULONG64 arg0, UINT arg1, PVOID arg2, PVOID arg3, ULONG64 arg4);
NTSTATUS __fastcall HookFunction(ULONG64 arg0, UINT arg1, MEMORY_STRUCT* arg2, PVOID arg3, ULONG64 arg4) 
{
	/*PKTHREAD_META p_thread_meta_data = ((PKTHREAD_META)((uintptr_t)KeGetCurrentThread()));

	if (p_thread_meta_data->ApcQueueable == 1)
		p_thread_meta_data->ApcQueueable = 0;*/

	if (ExGetPreviousMode() != UserMode)
	{
		return OriginalFunction(arg0, arg1, arg2, arg3, arg4);
	}

	if (!arg2)
	{
		return OriginalFunction(arg0, arg1, arg2, arg3, arg4);
	}

	MEMORY_STRUCT* m = (MEMORY_STRUCT*)arg2;

	if (arg4 != 0xDEADBEEF)
	{
		return OriginalFunction(arg0, arg1, arg2, arg3, arg4);
	}

	if (m->type == 1)
	{
		if (!m->address || !m->size || !m->target_pid) return STATUS_INVALID_PARAMETER_1;

		PEPROCESS target_process;
		if (NT_SUCCESS(PsLookupProcessByProcessId((HANDLE)m->target_pid, &target_process)))
		{
			SIZE_T bytes = 0;
			NTSTATUS x = MmCopyVirtualMemory(PsGetCurrentProcess(), m->output, target_process, m->address, m->size, UserMode, &bytes);
		}
	}
	else if (m->type == 2)
	{

		if (!m->address || !m->size || !m->target_pid) return STATUS_INVALID_PARAMETER_1;

		PEPROCESS target_process;
		if (NT_SUCCESS(PsLookupProcessByProcessId((HANDLE)m->target_pid, &target_process)))
		{
			SIZE_T bytes = 0;
			NTSTATUS x = MmCopyVirtualMemory(target_process, m->address, PsGetCurrentProcess(), m->output, m->size, UserMode, &bytes);
		}
	}
	else if (m->type == 3)
	{
		/*PEPROCESS process;
		if (NT_SUCCESS(PsLookupProcessByProcessId((HANDLE)m->target_pid, &process))) {
			m->output = (void*)PsGetProcessPeb(process);
		}*/
	}
	else if (m->type == 4)
	{
		/*PEPROCESS process = { 0 };
		if (NT_SUCCESS(PsLookupProcessByProcessId((HANDLE)m->target_pid, &process))) {
			m->base_address = (ULONG64)PsGetProcessSectionBaseAddress(process);
		}*/

		ANSI_STRING x;
		UNICODE_STRING game_module;
		RtlInitAnsiString(&x,"Prospect-Win64-Shipping.exe");
		RtlAnsiStringToUnicodeString(&game_module, &x, TRUE);

		PEPROCESS usermode;
		PsLookupProcessByProcessId((HANDLE)m->target_pid, &usermode);

		ULONG64 base_address = NULL;
		base_address = GetModuleBaseFor64BitProcess(usermode, game_module);
		m->base_address = base_address;
		RtlFreeUnicodeString(&game_module);

		return 0;
	}
	else if (m->type == 5) {

		/*uint64_t baseAddress = NULL;
		if (NT_SUCCESS(GetModuleBaseAddress(m->target_pid, m->ModuleName, &baseAddress)))
			m->base_address = (uint64_t)baseAddress;*/
	}
	else if (m->type == 6) 
	{
		/*SetGuardedRegion();*/
	}
	else if (m->type == 7)
	{
		/*ReadGuardedRegion(
			m->Displacement,
			m->Buffer,
			m->Size,
			m->X,
			m->Y);*/
	}
	else if (m->type == 8)
	{
		m->output = (void*)change_window_tree_protection((arg2));
	}
	else
	{
		return OriginalFunction(arg0, arg1, arg2, arg3, arg4);
	}

	/*if (p_thread_meta_data->ApcQueueable == 0)
		p_thread_meta_data->ApcQueueable = 1;*/

	return OriginalFunction(arg0, arg1, arg2, arg3, arg4);
}
NTSTATUS InstallHook(const ULONG64 vtable_inst) {
	ULONG64 vtable_addr = RVA(vtable_inst, (7));
	ULONG64* vtable = (ULONG64*)vtable_addr;
	BYTE vindex = (((BYTE)index + (6)) & (0x1F));
	if (MmIsAddressValid((void*)vtable[vindex])) {
		*(ULONG64*)&OriginalFunction = vtable[vindex];
		vtable[vindex] = (ULONG64)HookFunction;
		return STATUS_SUCCESS;
	}
	return STATUS_UNSUCCESSFUL;
}
NTSTATUS DrvEntry(ULONG64 base_address)
{
	uintptr_t drvbase;
	size_t drvsize;
	auto driver_status = find_kernel_module(_("win32kfull.sys"), &drvbase, &drvsize);
	if (NT_SUCCESS(driver_status)) {
		auto vtable_inst = find_pattern(drvbase, drvsize, _("\x48\x8D\x05\x00\x00\x00\x00\x41\x83\xC2\x06"), _("xxx????xxxx"));
		if (MmIsAddressValid((void*)vtable_inst) && vtable_inst != 0) {
			return InstallHook(vtable_inst);
		}
		else {
			vtable_inst = find_pattern(drvbase, drvsize, _("\x48\x8D\x05\x00\x00\x00\x00\x41\x83\xC1\x06\x41\x83\xE1\x1F\x4A\x8B\x04\xC8\x4C\x8B\x44\x24\x00\x8B\xD7"), _("xxx????xxxxxxxxxxxxxxxx?xx"));
			if (MmIsAddressValid((void*)vtable_inst)) {
				return InstallHook(vtable_inst);
			}
		}
	}
	return STATUS_UNSUCCESSFUL;
}
